import os
import sqlite3
from threading import Thread

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Line, Rectangle

try:
    from google import genai
except ImportError:
    genai = None

DB_NAME = "trading_pro.db"


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS strategies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            rules TEXT NOT NULL
        )
    """)
    cur.execute("SELECT COUNT(*) FROM strategies")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO strategies (name, rules) VALUES (?, ?)",
            (
                "HCS 3X / Scalping",
                "Use liquidity sweep, displacement, market structure and X3 negation. "
                "Risk maximum 1% per trade. Return BUY, SELL or HOLD only when conditions support it."
            ),
        )
    conn.commit()
    conn.close()


def get_strategy():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT rules FROM strategies ORDER BY id LIMIT 1")
    row = cur.fetchone()
    conn.close()
    return row[0] if row else "No strategy defined."


class ChartWidget(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.signal_type = "HOLD"
        self.bind(size=self._redraw, pos=self._redraw)
        Clock.schedule_once(lambda dt: self._redraw(), 0)

    def _redraw(self, *args):
        self.canvas.before.clear()
        self.canvas.after.clear()
        with self.canvas.before:
            Color(0.055, 0.06, 0.075, 1)
            self.rect = Rectangle(pos=self.pos, size=self.size)
            Color(0.18, 0.18, 0.21, 1)
            for i in range(1, 6):
                y = self.y + self.height * i / 6
                Line(points=[self.x, y, self.right, y], width=0.7)

        with self.canvas.after:
            if self.signal_type == "BUY":
                Color(0.15, 0.85, 0.35, 1)
            elif self.signal_type == "SELL":
                Color(0.95, 0.25, 0.25, 1)
            else:
                Color(0.65, 0.65, 0.7, 1)

            x, y, w, h = self.x, self.y, self.width, self.height
            points = [
                x + w * 0.08, y + h * 0.35,
                x + w * 0.22, y + h * 0.42,
                x + w * 0.35, y + h * 0.30,
                x + w * 0.48, y + h * 0.52,
                x + w * 0.62, y + h * 0.45,
                x + w * 0.76, y + h * 0.68,
                x + w * 0.90, y + h * 0.60,
            ]
            Line(points=points, width=1.8)


class TradingApp(App):
    def build(self):
        init_db()

        root = BoxLayout(orientation="vertical", padding=10, spacing=8)

        header = Label(
            text="[b]TRADING AI COPILOT[/b]\\nEUR/USD • H1",
            markup=True,
            size_hint_y=0.11,
            color=(1, 1, 1, 1),
        )
        root.add_widget(header)

        self.chart = ChartWidget(size_hint_y=0.34)
        root.add_widget(self.chart)

        scroll = ScrollView(size_hint_y=0.39)
        self.ai_output = Label(
            text="Savol yoki market ma'lumotini kiriting...",
            size_hint_y=None,
            text_size=(None, None),
            halign="left",
            valign="top",
            color=(0.92, 0.92, 0.94, 1),
        )
        self.ai_output.bind(texture_size=self._fit_output)
        scroll.add_widget(self.ai_output)
        root.add_widget(scroll)

        bottom = BoxLayout(orientation="horizontal", size_hint_y=0.12, spacing=6)
        self.user_input = TextInput(
            hint_text="Masalan: RSI 75, liquidity sweep...",
            multiline=False,
            background_color=(0.12, 0.13, 0.16, 1),
            foreground_color=(1, 1, 1, 1),
        )
        btn = Button(
            text="AI ANALIZ",
            size_hint_x=0.30,
            background_color=(0.05, 0.45, 0.85, 1),
        )
        btn.bind(on_press=self.analyze_market)
        bottom.add_widget(self.user_input)
        bottom.add_widget(btn)
        root.add_widget(bottom)

        return root

    def _fit_output(self, instance, size):
        instance.height = size[1]
        instance.text_size = (self.width - 20, None)

    def analyze_market(self, instance):
        query = self.user_input.text.strip()
        if not query:
            return

        self.ai_output.text = "AI tahlil qilmoqda..."
        self.chart.signal_type = "HOLD"
        self.chart._redraw()
        Thread(target=self._process_ai, args=(query,), daemon=True).start()

    def _process_ai(self, query):
        strategy = get_strategy()
        api_key = os.environ.get("GEMINI_API_KEY", "").strip()

        if genai is None:
            result = "Gemini kutubxonasi topilmadi.\n\nITOG: HOLD"
        elif not api_key:
            result = (
                "GEMINI_API_KEY o'rnatilmagan. Avval API kalitni sozlang.\n\n"
                "ITOG: HOLD"
            )
        else:
            try:
                client = genai.Client(api_key=api_key)
                prompt = f"""
You are a trading analysis assistant.
User strategy:
{strategy}

User market input:
{query}

Analyze only the information provided. Do not invent live prices or candles.
Explain briefly in Uzbek.
At the end write exactly one of:
ITOG: BUY
ITOG: SELL
ITOG: HOLD

This is educational market analysis, not a guaranteed trading signal.
"""
                response = client.models.generate_content(
                    model="gemini-2.5-flash",
                    contents=prompt,
                )
                result = response.text or "AI javob bermadi.\n\nITOG: HOLD"
            except Exception as exc:
                result = f"Gemini xatosi: {exc}\n\nITOG: HOLD"

        Clock.schedule_once(lambda dt: self._show_result(result), 0)

    def _show_result(self, result):
        self.ai_output.text = result
        upper = result.upper()
        if "ITOG: BUY" in upper:
            self.chart.signal_type = "BUY"
        elif "ITOG: SELL" in upper:
            self.chart.signal_type = "SELL"
        else:
            self.chart.signal_type = "HOLD"
        self.chart._redraw()


if __name__ == "__main__":
    TradingApp().run()
