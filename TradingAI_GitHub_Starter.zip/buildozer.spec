[app]
title = Trading AI Copilot
package.name = tradingaicopilot
package.domain = org.tradingai
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt
version = 1.0.0
requirements = python3,kivy,google-genai
orientation = portrait
fullscreen = 0

# Android
android.api = 35
android.minapi = 23
android.ndk = 27c
android.permissions = INTERNET
android.archs = arm64-v8a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
