# Trading AI Copilot

Kivy Android trading-analysis app with SQLite strategy storage and Gemini AI.

## Local setup

1. Install Python 3.11.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Set `GEMINI_API_KEY`.
4. Run:
   `python main.py`

## GitHub APK

Push the project to a GitHub repository. The GitHub Actions workflow builds a debug APK.

Open:
Actions → Build Android APK → workflow run → Artifacts → trading-ai-apk.

## Important

The current version does not claim to receive live market data. It analyzes only user-provided information.

Next modules can add a real OHLC source and a deterministic HCS 3X pattern engine.
